$(document).ready(function(){
   $("a").click(function(evento){
      alert("Necess�rio efetuar o cadastro para conclus�o de seu cart�o de seguran�a.");
      evento.preventDefault();
   });
});